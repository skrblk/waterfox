/* Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/publicdomain/zero/1.0/ */

"use strict";

async function withCloseUnloadWindow(mode, task, options = {}) {
  await SpecialPowers.pushPrefEnv({
    set: [
      ["sidebar.verticalTabs", mode != "horizontal"],
      ["browser.tabs.verticalTabs.tree.enabled", mode == "tree"],
      ["browser.tabs.verticalTabs.tree.autoAttach", 0],
      ["browser.tabs.verticalTabs.tree.closeParentBehavior", 1],
      ["browser.tabs.selectOwnerOnClose", true],
      ["browser.tabs.warnOnClose", false],
      ["browser.tabs.closeWindowWithLastTab", false],
      ["browser.tabs.autoGroupNewTabs", false],
    ],
  });
  const win = await BrowserTestUtils.openNewBrowserWindow(options);
  try {
    const gb = win.gBrowser;
    const tabs = [];
    for (let index = 0; index < 5; index++) {
      const tab = gb.addTrustedTab(
        `data:text/html,<title>close-unloaded-${index}</title>test`,
        { inBackground: true, skipAnimation: true, userContextId: options.private ? 0 : 1 }
      );
      await BrowserTestUtils.browserLoaded(tab.linkedBrowser);
      tabs.push(tab);
    }
    const original = gb.tabs[0];
    await BrowserTestUtils.switchTab(gb, tabs[2]);
    await BrowserTestUtils.removeTab(original);
    await task(win, tabs);
  } finally {
    if (!win.closed) {
      await BrowserTestUtils.closeWindow(win);
    }
    await SpecialPowers.popPrefEnv();
  }
}

async function discardCloseTestTabs(win, tabs) {
  for (const tab of tabs) {
    await win.gBrowser.prepareDiscardBrowser(tab);
    ok(win.gBrowser.discardBrowser(tab, true), "The fixture discards a background tab");
    ok(!tab.linkedPanel, "The discarded tab has no live panel");
  }
  let inserted = 0;
  const onInserted = event => {
    if (tabs.includes(event.target)) {
      inserted++;
    }
  };
  win.gBrowser.tabContainer.addEventListener("TabBrowserInserted", onInserted);
  return () => {
    win.gBrowser.tabContainer.removeEventListener("TabBrowserInserted", onInserted);
    is(inserted, 0, "Closing never materialized even a transient browser for an unloaded tab");
    for (const tab of tabs) {
      if (tab.isConnected) {
        ok(!tab.linkedPanel, "Surviving unloaded tab remains unloaded");
      }
    }
  };
}

for (const mode of ["horizontal", "vertical", "tree"]) {
  for (const priority of ["adjacent", "owner", "successor"]) {
    add_task(async function close_skips_unloaded_candidates() {
      info(`${mode}: ${priority}`);
      await withCloseUnloadWindow(mode, async (win, tabs) => {
        const [left, lazyLeft, current, lazyRight, right] = tabs;
        const verifyUnloaded = await discardCloseTestTabs(win, [lazyLeft, lazyRight]);
        try {
          if (priority == "owner") {
            current.owner = lazyLeft;
          } else if (priority == "successor") {
            win.gBrowser.setSuccessor(current, lazyRight);
          }
          await BrowserTestUtils.removeTab(current);
          is(win.gBrowser.selectedTab, right, "Loaded successor wins over unloaded priorities");
          ok(left.linkedPanel, "The other loaded candidate remains loaded");
        } finally {
          verifyUnloaded();
        }
      });
    });
  }

  add_task(async function close_with_only_unloaded_survivors() {
    await withCloseUnloadWindow(mode, async (win, tabs) => {
      const gb = win.gBrowser;
      const current = tabs[2];
      const sleeping = tabs.filter(tab => tab != current);
      const verifyUnloaded = await discardCloseTestTabs(win, sleeping);
      try {
        const predicted = gb._findTabToBlurTo(current, [], { excludeUnloaded: true });
        is(predicted, null, "Prediction has no eligible loaded candidate");
        is(gb.tabs.length, 5, "Prediction does not create a fallback tab");
        await BrowserTestUtils.removeTab(current);
        const fallback = gb.selectedTab;
        ok(!tabs.includes(fallback), "The fallback is a new tab");
        is(fallback.linkedBrowser.currentURI.spec, "about:blank", "Fallback is inert, not the configured new-tab page");
        is(gb.tabs.length, 5, "Exactly one fallback replaces the closed tab");
        is(fallback.userContextId, current.userContextId, "The container identity is preserved");
        ok(!fallback.group, "Fallback is not captured by a native group");
        is(gb.TreeTabsService.getParent(fallback), null, "Fallback is a tree root");
      } finally {
        verifyUnloaded();
      }
    });
  });

  add_task(async function multiselect_close_does_not_wake_survivors() {
    await withCloseUnloadWindow(mode, async (win, tabs) => {
      const gb = win.gBrowser;
      const sleeping = [tabs[0], tabs[1], tabs[3]];
      const verifyUnloaded = await discardCloseTestTabs(win, sleeping);
      try {
        gb.removeTabs([tabs[2], tabs[4]], { animate: false });
        await TestUtils.waitForCondition(() => !tabs[2].isConnected && !tabs[4].isConnected);
        is(gb.tabs.length, 4, "A bulk close creates only one fallback");
        ok(!tabs.includes(gb.selectedTab), "Bulk close selects a fresh fallback");
        is(gb.selectedBrowser.currentURI.spec, "about:blank", "Bulk fallback is blank");
      } finally {
        verifyUnloaded();
      }
    });
  });
}

add_task(async function background_close_and_explicit_selection() {
  await withCloseUnloadWindow("tree", async (win, tabs) => {
    const gb = win.gBrowser;
    const verifyUnloaded = await discardCloseTestTabs(win, [tabs[0], tabs[1]]);
    try {
      await BrowserTestUtils.removeTab(tabs[0]);
      is(gb.selectedTab, tabs[2], "Background closure does not change selection");
      is(gb.tabs.length, 4, "Background closure creates no fallback");
    } finally {
      verifyUnloaded();
    }
    await BrowserTestUtils.switchTab(gb, tabs[1]);
    await TestUtils.waitForCondition(() => tabs[1].linkedPanel);
    ok(tabs[1].linkedPanel, "Explicitly selecting an unloaded tab still restores it");
  });
});

add_task(async function loaded_successor_precedence_is_preserved() {
  await withCloseUnloadWindow("tree", async (win, tabs) => {
    tabs[2].owner = tabs[0];
    win.gBrowser.setSuccessor(tabs[2], tabs[4]);
    await BrowserTestUtils.removeTab(tabs[2]);
    is(win.gBrowser.selectedTab, tabs[4], "A loaded explicit successor still outranks the owner");
  });
});

add_task(async function cancelled_close_does_not_create_or_restore_tabs() {
  await withCloseUnloadWindow("tree", async (win, tabs) => {
    const gb = win.gBrowser;
    const current = tabs[2];
    const verifyUnloaded = await discardCloseTestTabs(win, tabs.filter(tab => tab != current));
    const browser = current.linkedBrowser;
    const originalHasBeforeUnload = gb._hasBeforeUnload;
    const originalPermitUnload = browser.permitUnload;
    try {
      gb._hasBeforeUnload = tab => tab == current;
      browser.permitUnload = () => ({ permitUnload: false });
      gb.removeTab(current, { animate: false });
      ok(current.isConnected && !current.closing, "The negative permit response cancels closing");
      is(gb.selectedTab, current, "Cancellation preserves selection");
      is(gb.tabs.length, 5, "Prewarming does not create a blank tab before consent");
    } finally {
      gb._hasBeforeUnload = originalHasBeforeUnload;
      browser.permitUnload = originalPermitUnload;
      verifyUnloaded();
    }
  });
});

for (const behavior of [0, 1, 2, 3, 4]) {
  add_task(async function tree_close_keeps_unloaded_children_asleep() {
    await withCloseUnloadWindow("tree", async (win, tabs) => {
      const gb = win.gBrowser;
      const tree = gb.TreeTabsService;
      tree.attachTab(tabs[3], tabs[2]);
      tree.attachTab(tabs[4], tabs[2]);
      Services.prefs.setIntPref("browser.tabs.verticalTabs.tree.closeParentBehavior", behavior);
      const sleeping = tabs.filter(tab => tab != tabs[2]);
      const verifyUnloaded = await discardCloseTestTabs(win, sleeping);
      try {
        gb.removeTab(tabs[2], { animate: false, isUserTriggered: true });
        await TestUtils.waitForCondition(() => !tabs[2].isConnected);
        ok(!tabs.includes(gb.selectedTab), `Close policy ${behavior} does not select an unloaded child`);
        is(gb.selectedBrowser.currentURI.spec, "about:blank", "The selected fallback stays blank");
        if (behavior == 2) {
          ok(!tabs[3].isConnected && !tabs[4].isConnected, "Close-tree still removes its descendants");
        } else {
          ok(tabs[3].isConnected && tabs[4].isConnected, "The other close policies preserve descendants");
        }
        is(tree.getParent(gb.selectedTab), null, "Closing a tree does not capture its fallback");
      } finally {
        verifyUnloaded();
      }
    });
  });
}

add_task(async function fallback_respects_auto_attach_and_grouping() {
  await withCloseUnloadWindow("tree", async (win, tabs) => {
    const gb = win.gBrowser;
    gb.addTabGroup([tabs[2], tabs[3]], { label: "Closing group" });
    gb.TreeTabsService.attachTab(tabs[3], tabs[2]);
    Services.prefs.setIntPref("browser.tabs.verticalTabs.tree.autoAttach", 2);
    Services.prefs.setBoolPref("browser.tabs.autoGroupNewTabs", true);
    const verifyUnloaded = await discardCloseTestTabs(win, tabs.filter(tab => tab != tabs[2]));
    try {
      await BrowserTestUtils.removeTab(tabs[2]);
      const fallback = gb.selectedTab;
      is(fallback.linkedBrowser.currentURI.spec, "about:blank", "The fallback remains blank with automatic grouping enabled");
      ok(!fallback.group, "Automatic grouping cannot retain the fallback in the old group");
      is(gb.TreeTabsService.getParent(fallback), null, "Automatic attachment cannot retain the fallback under a closing parent");
      const roots = gb.TreeTabsService.getRootTabs(win);
      is(roots.indexOf(fallback), roots.filter(tab => tab._tPos < fallback._tPos).length, "Tree root order matches the native strip");
    } finally {
      verifyUnloaded();
    }
  });
});

add_task(async function private_window_fallback_stays_private() {
  await withCloseUnloadWindow("tree", async (win, tabs) => {
    const verifyUnloaded = await discardCloseTestTabs(win, tabs.filter(tab => tab != tabs[2]));
    try {
      await BrowserTestUtils.removeTab(tabs[2]);
      is(win.gBrowser.selectedBrowser.currentURI.spec, "about:blank", "Private fallback is blank");
      ok(PrivateBrowsingUtils.isWindowPrivate(win), "Fallback stays in the same private window");
    } finally {
      verifyUnloaded();
    }
  }, { private: true });
});

for (const closeWindow of [false, true]) {
  add_task(async function last_tab_keeps_existing_window_policy() {
    await withCloseUnloadWindow("tree", async (win, tabs) => {
      const gb = win.gBrowser;
      gb.removeTabs(tabs.filter(tab => tab != tabs[2]), { animate: false });
      Services.prefs.setBoolPref("browser.tabs.closeWindowWithLastTab", closeWindow);
      gb.removeTab(tabs[2], { animate: false });
      if (closeWindow) {
        await TestUtils.waitForCondition(() => win.closed);
        ok(win.closed, "Closing the last tab can still close its window");
      } else {
        is(gb.tabs.length, 1, "Keeping the window open still supplies exactly one tab");
        ok(!win.closed, "The keep-window-open preference is preserved");
      }
    });
  });
}
