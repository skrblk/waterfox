"""Upload verified file bytes as unattached Git blobs, without moving refs."""
import base64
import hashlib
import json
import os
from pathlib import Path
from urllib.request import Request, urlopen

files = {
    'browser/components/tabbrowser/content/tabbrowser.js': 'artifacts/tabbrowser.js',
    'browser/components/tabbrowser/test/browser/tabs/browser.toml': 'artifacts/browser.toml',
    'browser/components/tabbrowser/test/browser/tabs/browser_close_unloaded_tabs.js': 'work/browser_close_unloaded_tabs.js',
}
result = {}
for path, local in files.items():
    data = Path(local).read_bytes()
    expected = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    req = Request(f'https://api.github.com/repos/{os.environ["GITHUB_REPOSITORY"]}/git/blobs',
                  data=json.dumps({'content': base64.b64encode(data).decode(), 'encoding': 'base64'}).encode(),
                  headers={'Authorization': f'Bearer {os.environ["GH_TOKEN"]}', 'Accept':'application/vnd.github+json','Content-Type':'application/json'}, method='POST')
    with urlopen(req, timeout=30) as response:
        blob = json.load(response)
    assert blob['sha'] == expected
    result[path] = {'sha': expected, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
Path('artifacts/verified-blobs.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
