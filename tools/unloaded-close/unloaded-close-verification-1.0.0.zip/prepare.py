"""Build a narrowly anchored candidate against the inspected source revision."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import struct
import zipfile

ROOT = Path('work')
ARTIFACTS = Path('artifacts')
ARTIFACTS.mkdir(exist_ok=True)

def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def replace_once(source, old, new):
    count = source.count(old)
    if count != 1:
        raise ValueError(f'Expected exactly one anchor, got {count}: {old[:100]!r}')
    return source.replace(old, new, 1)


def patch(source):
    source = replace_once(source,
        'let toBlurTo = this._findTabToBlurTo(lastToClose, tabs);',
        'let toBlurTo = this._findTabToBlurTo(lastToClose, tabs, {\n            excludeUnloaded: true,\n          });')
    source = replace_once(source,
        'let blurTab = this._findTabToBlurTo(aTab);',
        'let blurTab = this._findTabToBlurTo(aTab, [], {\n            excludeUnloaded: true,\n          });')
    source = replace_once(source,
        '     *          closed along with aTab)\n     */\n    _findTabToBlurTo(aTab, aExcludeTabs = []) {',
        '     *          closed along with aTab)\n     * @param   {object} [options]\n     * @param   {boolean} [options.excludeUnloaded=false]\n     *          Avoid restoring unloaded tabs when choosing a close successor.\n     */\n    _findTabToBlurTo(\n      aTab,\n      aExcludeTabs = [],\n      { excludeUnloaded = false } = {}\n    ) {')
    source = replace_once(source,
        '      let excludeTabs = new Set(aExcludeTabs);\n',
        '      let excludeTabs = new Set(aExcludeTabs);\n      if (excludeUnloaded) {\n        for (const tab of this.tabs) {\n          if (!tab.linkedPanel || tab.closing || tab._closedInMultiselection) {\n            excludeTabs.add(tab);\n          }\n        }\n      }\n')
    source = replace_once(source,
        '    _blurTab(aTab) {\n      this.selectedTab = this._findTabToBlurTo(aTab);\n    }',
        '''    _blurTab(aTab) {
      if (!aTab.selected) {
        return;
      }
      let nextTab = this._findTabToBlurTo(aTab, [], {
        excludeUnloaded: true,
      });
      if (
        !nextTab &&
        !this.#windowIsClosing &&
        !this.#isLastTabInWindow(aTab)
      ) {
        // Keep the fallback outside the closing tree or native group.
        const treeTabs = this.TreeTabsService;
        const root = treeTabs.getAncestors(aTab).at(-1) || aTab;
        const anchor =
          aTab.group?.tabs.at(-1) || treeTabs.getSubtreeEndAnchor(root) || aTab;
        nextTab = this.addTrustedTab("about:blank", {
          inBackground: true,
          skipAnimation: true,
          tabIndex: anchor._tPos + 1,
          userContextId: aTab.userContextId,
        });
        if (nextTab.group) {
          this.ungroupTab(nextTab);
        }
        if (treeTabs.enabled) {
          treeTabs.detachTab(nextTab);
          treeTabs.onTabMoved(nextTab);
        }
      }
      this.selectedTab = nextTab;
    }''')
    return source


def open_omni(path):
    data = path.read_bytes()
    try:
        return zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        # Optimized omnijars put the central directory before the local files.
        end = data.rfind(b'PK\x05\x06')
        if end < 0:
            raise
        footer = list(struct.unpack_from('<4s4H2LH', data, end))
        size, offset = footer[5:7]
        directory = data[offset:offset + size]
        if not directory.startswith(b'PK\x01\x02'):
            raise ValueError('Unsupported optimized-jar directory layout')
        footer[6] = len(data)
        normalized = data + directory + struct.pack('<4s4H2LH', *footer) + data[end + 22:end + 22 + footer[7]]
        return zipfile.ZipFile(io.BytesIO(normalized))


def main():
    raw = (ROOT / 'tabbrowser.js').read_bytes()
    assert git_blob(raw) == '4f3a778c7dba451f4a5332f26ebebf28ac6a1883'
    source = raw.decode()
    changed = patch(source)
    (ARTIFACTS / 'tabbrowser.js').write_text(changed)
    manifest = (ROOT / 'browser.toml').read_text()
    assert git_blob(manifest.encode()) == '9f16c7d9d9a70fb7dd2651ad9dcea7d019b4b804'
    revised_manifest = replace_once(manifest,
        '["browser_contextmenu_openlink_after_tabnavigated.js"]',
        '["browser_close_unloaded_tabs.js"]\ntags = "vertical-tabs"\n\n["browser_contextmenu_openlink_after_tabnavigated.js"]')
    (ARTIFACTS / 'browser.toml').write_text(revised_manifest)
    (ARTIFACTS / 'candidate.patch').write_text(''.join(difflib.unified_diff(
        source.splitlines(True), changed.splitlines(True),
        fromfile='a/browser/components/tabbrowser/content/tabbrowser.js',
        tofile='b/browser/components/tabbrowser/content/tabbrowser.js')))
    patched = []
    for archive in (ROOT / 'waterfox').rglob('omni.ja'):
        with open_omni(archive) as old:
            targets = [n for n in old.namelist() if n.endswith('/tabbrowser.js')]
            if not targets:
                continue
            assert len(targets) == 1
            target = targets[0]
            packaged = old.read(target)
            (ARTIFACTS / 'packaged-tabbrowser-original.js').write_bytes(packaged)
            candidate = patch(packaged.decode()).encode()
            temp = archive.with_suffix('.patched')
            with zipfile.ZipFile(temp, 'w') as new:
                for entry in old.infolist():
                    new.writestr(entry, candidate if entry.filename == target else old.read(entry.filename))
            patched.append({'archive': str(archive), 'entry': target,
                'original_sha256': hashlib.sha256(packaged).hexdigest(),
                'patched_sha256': hashlib.sha256(candidate).hexdigest(),
                'source_equals_package': packaged == raw})
        temp.replace(archive)
    assert len(patched) == 1, patched
    (ARTIFACTS / 'package-comparison.json').write_text(json.dumps(patched, indent=2))
    print(json.dumps(patched, indent=2))


if __name__ == '__main__':
    main()
